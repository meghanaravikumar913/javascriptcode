let btnopen = document.querrySelector('button');
let input = document.querySelector('input');

btopen.addEventListener('click', () =>){
	window.open(input.value, 'blank', 'height=700px',width=400px');
});